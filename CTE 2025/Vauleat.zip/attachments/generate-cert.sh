#!/bin/bash

mkdir -p ssl

openssl genrsa -out ssl/server.key 2048

openssl req -new -key ssl/server.key -out ssl/server.csr -subj "/C=US/ST=CA/L=San Francisco/O=Test/OU=Test/CN=localhost"

openssl x509 -req -days 365 -in ssl/server.csr -signkey ssl/server.key -out ssl/server.crt

chmod 644 ssl/server.crt
chmod 600 ssl/server.key

echo "SSL certificate generated successfully!"
echo "Certificate: ssl/server.crt"
echo "Private key: ssl/server.key"
