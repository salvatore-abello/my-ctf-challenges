import sys
import time
import hashlib
import requests


def get_pow_challenge(base_url):
    response = requests.get(f"{base_url}/report/pow", verify=False)
    response.raise_for_status()
    return response.json()

def count_leading_zero_bits(data: bytes) -> int:
    bits = 0
    for byte in data:
        if byte == 0:
            bits += 8
            continue
        
        for i in range(7, -1, -1):
            if (byte & (1 << i)) == 0:
                bits += 1
            else:
                return bits
    return bits

def solve_pow(token: str, difficulty: int) -> str:
    print(f"Solving PoW challenge (difficulty: {difficulty})...")
    start_time = time.time()
    
    nonce = 0
    while True:
        hash_input = f"{token}.{nonce}"
        
        hash_bytes = hashlib.sha256(hash_input.encode()).digest()
        
        leading_zeros = count_leading_zero_bits(hash_bytes)
        
        if leading_zeros >= difficulty:
            elapsed = time.time() - start_time
            print(f"PoW solved! Nonce: {nonce}, Time: {elapsed:.2f}s")
            return str(nonce)
        
        nonce += 1
        
        if nonce % 100000 == 0:
            elapsed = time.time() - start_time
            rate = nonce / elapsed if elapsed > 0 else 0
            print(f"Trying nonce {nonce:,} (rate: {rate:,.0f}/s)")

def submit_url(base_url, url):
    print("Fetching challenge...")
    
    challenge = get_pow_challenge(base_url)
    print(f"challenge: {challenge}")
    
    nonce = solve_pow(challenge['token'], challenge['difficulty'])
    
    pow_solution = {
        'token': challenge['token'],
        'nonce': nonce,
        'sig': challenge['sig'],
        'expires': challenge['expires'],
        'difficulty': challenge['difficulty']
    }
    
    payload = {
        'url': url,
        'pow': pow_solution
    }
    
    print("Submitting report...")
    
    response = requests.post(
        f"{base_url}/report",
        json=payload, verify=False
    )
    
    if response.status_code == 200:
        result = response.text
        print(f"Success: {result}")
        return result
    else:
        error_msg = f"Error {response.status_code}: {response.text}"
        print(error_msg)
        raise Exception(error_msg)

def main():
    if len(sys.argv) != 3:
        print("Usage: python report_url.py <base_url> <url>")
        sys.exit(1)
    
    base_url = sys.argv[1]
    url = sys.argv[2]
    try:
        submit_url(base_url, url)
    except KeyboardInterrupt:
        sys.exit(1)
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
