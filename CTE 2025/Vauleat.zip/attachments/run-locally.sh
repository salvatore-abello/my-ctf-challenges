#!/bin/bash

echo "Deploying with HTTPS..."

if [ ! -f "ssl/server.key" ] || [ ! -f "ssl/server.crt" ]; then
    echo "Generating SSL certificates..."
    ./generate-cert.sh
fi

docker compose down
docker compose up --build -d
