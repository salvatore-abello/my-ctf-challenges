import express from 'express';
import session from 'express-session';
import flash from 'connect-flash';
import path from 'path';
import crypto from "crypto";
import https from 'https';
import fs from 'fs';

import { fileURLToPath } from 'url';

import { nonceMiddleware, addHeadersMiddleware, maliciousRequestsMiddleware } from './middleware/security.js';
import { initializeDatabase } from './db.js';
import indexRoutes from './routes/index.js';
import authRoutes from './routes/auth.js';
import recipesRoutes from './routes/recipes.js';
import reportRoutes from './routes/report.js';


const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename); 

const app = express();

const TESTING =
  process.env.TESTING === undefined
    ? true
    : String(process.env.TESTING).trim().toLowerCase() === 'true';

app.set('trust proxy', 1);
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, '..', 'views'));
app.use('/static', express.static(path.join(__dirname, '..', 'public')));

app.use(express.urlencoded({ extended: true }));
app.use(express.json());

app.use(session({
  secret: process.env.SESSION_SECRET || crypto.randomBytes(32).toString('hex'),
  resave: false,
  saveUninitialized: false,
  cookie: { 
    httpOnly: true,
    sameSite: 'None',
    secure: true
  }
}));
app.use(flash());

app.use(nonceMiddleware);
app.use(addHeadersMiddleware);
app.use(maliciousRequestsMiddleware);

app.use((req, res, next) => {
  res.locals.currentUser = req.session.user || null;
  res.locals.flash = {
    success: req.flash('success'),
    error: req.flash('error'),
  };

  next();
});

app.use('/', indexRoutes);
app.use('/', authRoutes);
app.use('/', reportRoutes);
app.use('/recipes', recipesRoutes);

const port = 3000;

const startServer = async () => {
  const maxRetries = 20;
  const delayMs = 3000;
  let attempt = 0;

  while (attempt < maxRetries) {
    try {
      await initializeDatabase();
      console.log('Database initialized successfully');
      break;
    } catch (error) {
      attempt++;
      console.error(`Database not ready (attempt ${attempt}/${maxRetries}):`, error.message);
      if (attempt >= maxRetries) {
        console.error('Giving up: database did not become ready in time');
        process.exit(1);
      }
      await new Promise(resolve => setTimeout(resolve, delayMs));
    }
  }

  const sslKeyPath = path.join(__dirname, '..', '..', 'ssl', 'server.key');
  const sslCertPath = path.join(__dirname, '..', '..', 'ssl', 'server.crt');

  if (TESTING) {
    const sslOptions = {
      key: fs.readFileSync(sslKeyPath),
      cert: fs.readFileSync(sslCertPath)
    };

    const httpsServer = https.createServer(sslOptions, app);
    httpsServer.listen(port, () => {
      console.log(`(testing) HTTPS Server running on https://localhost:${port}`);
    });
  } else {
    app.listen(port, () => {
      console.log(`HTTP Server running on http://localhost:${port}`);
    });
  }
};

startServer()