import { Router } from 'express';
import { Recipes } from '../db.js';
import { mdToHtml, truncate, difficultyClass } from '../utils/format.js';

const router = Router();

const transformRecipe = (recipe) => ({
  ...recipe,
  description: mdToHtml(truncate(recipe.description || '', 120)),
  difficultyClass: difficultyClass(recipe.difficulty),
  servings: Number(recipe.servings) || 0,
  prep_time: String(recipe.prep_time || ''),
  cook_time: String(recipe.cook_time || '')
});

router.get('/', async (req, res) => {
  try {
    const user = req.session.user;
    const user_name = user ? user.name : 'Guest';
    let latest_recipes = [];

    if (user) {
      const rows = await Recipes.latestForUser(user.id);
      latest_recipes = rows.map(transformRecipe);
    }

    res.render('index', {
      active: 'home',
      user_name,
      latest_recipes
    });

  } catch (error) {
    console.error('Home page error:', error);
    
    req.flash('error', 'Unable to load recipes');
    res.render('index', {
      active: 'home',
      user_name: 'Guest',
      latest_recipes: []
    });
  }
});

export default router;