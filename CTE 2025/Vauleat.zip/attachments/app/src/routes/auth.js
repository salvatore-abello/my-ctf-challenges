import { Router } from 'express';
import bcrypt from 'bcryptjs';
import { Users, generateUUID } from '../db.js';
import { renderWithFlash, handleError } from '../utils/templates.js';
import { redirectIfAuthenticated } from '../middleware/auth.js';

const router = Router();

const BCRYPT_ROUNDS = 12;
const MIN_PASSWORD_LENGTH = 6;
const MAX_EMAIL_LENGTH = 256;
const MAX_NAME_LENGTH = 100;
const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

const validateEmail = (email) => {
  if (!email || typeof email !== 'string') 
    return { valid: false, message: 'Email is required' };
  
  if (email.length > MAX_EMAIL_LENGTH) 
    return { valid: false, message: 'Email is too long' };
  
  const cleanEmail = String(email).toLowerCase().trim();
  
  if (!EMAIL_REGEX.test(cleanEmail)) 
    return { valid: false, message: 'Please enter a valid email address' };
  
  return { valid: true, cleanEmail };
};

const validatePassword = (password, confirmPassword = null) => {
  if (!password || typeof password !== 'string') 
    return { valid: false, message: 'Password is required' };
  
  if (password.length < MIN_PASSWORD_LENGTH) 
    return { valid: false, message: `Password must be at least ${MIN_PASSWORD_LENGTH} characters long` };
  
  if (confirmPassword !== null && password !== confirmPassword) 
    return { valid: false, message: 'Passwords do not match' };
  
  return { valid: true };
};

const validateName = (name) => {
  if (!name || typeof name !== 'string') 
    return { valid: false, message: 'Name is required' };
  
  if (name.length > MAX_NAME_LENGTH) 
    return { valid: false, message: 'Name is too long' };
  
  const cleanName = String(name).trim();
  if (!cleanName) 
    return { valid: false, message: 'Name cannot be empty' };
  
  return { valid: true, cleanName };
};

router.post('/login', async (req, res) => {
  const { email, password } = req.body || {};
  const formData = { email: email || '' };
  
  try {
    if (!email || !password) {
      return renderWithFlash(req, res, 'login', 'login', { formData }, 'error', 'Email and password are required');
    }

    const emailValidation = validateEmail(email);
    if (!emailValidation.valid) {
      return renderWithFlash(req, res, 'login', 'login', { formData }, 'error', emailValidation.message);
    }

    const user = await Users.findByEmail(emailValidation.cleanEmail);
    if (!user) {
      return renderWithFlash(req, res, 'login', 'login', { formData }, 'error', 'Invalid email or password');
    }

    const isValidPassword = await bcrypt.compare(password, user.password_hash);
    if (!isValidPassword) {
      return renderWithFlash(req, res, 'login', 'login', { formData }, 'error', 'Invalid email or password');
    }

    req.session.user = { 
      id: user.id, 
      name: user.name, 
      email: user.email 
    };
    
    req.session.save((err) => {
      if (err) {
        console.error('Session save error:', err);
        return renderWithFlash(req, res, 'login', 'login', { formData }, 'error', 'Login failed. Please try again.');
      }
      
      req.flash('success', `Welcome back, ${user.name}!`);
      res.redirect('/');
    });

  } catch (error) {
    handleError(req, res, 'login', 'login', { formData }, error, 'An error occurred during login');
  }
});

router.post('/register', async (req, res) => {
  const { name, email, password, confirmPassword } = req.body || {};
  const formData = { name: name || '', email: email || '' };
  
  try {
    const nameValidation = validateName(name);
    if (!nameValidation.valid) {
      return renderWithFlash(req, res, 'register', 'register', { formData }, 'error', nameValidation.message);
    }

    const emailValidation = validateEmail(email);
    if (!emailValidation.valid) {
      return renderWithFlash(req, res, 'register', 'register', { formData }, 'error', emailValidation.message);
    }

    const passwordValidation = validatePassword(password, confirmPassword);
    if (!passwordValidation.valid) {
      return renderWithFlash(req, res, 'register', 'register', { formData }, 'error', passwordValidation.message);
    }

    const existingUser = await Users.findByEmail(emailValidation.cleanEmail);
    if (existingUser) {
      return renderWithFlash(req, res, 'register', 'register', { formData }, 'error', 'An account with this email already exists');
    }

    const passwordHash = await bcrypt.hash(password, BCRYPT_ROUNDS);
    const userId = generateUUID();
    await Users.create(userId, nameValidation.cleanName, emailValidation.cleanEmail, passwordHash);
    
    req.flash('success', 'Account created successfully! You can now log in.');
    res.redirect('/login');
    
  } catch (error) {
    handleError(req, res, 'register', 'register', { formData }, error, 'An error occurred during registration');
  }
});

router.post('/logout', (req, res) => {
  if (!req.session) {
    return res.redirect('/login');
  }
  
  req.session.destroy((err) => {
    if (err) {
      console.error('Logout error:', err);
      return res.redirect('/');
    }
    
    res.clearCookie('connect.sid');
    res.redirect('/login');
  });
});

router.get('/register', redirectIfAuthenticated, (req, res) => {
  res.render('register', { 
    active: 'register',
    formData: {}
  });
});

router.get('/login', redirectIfAuthenticated, (req, res) => {
  res.render('login', { 
    active: 'login',
    formData: {}
  });
});

export default router;