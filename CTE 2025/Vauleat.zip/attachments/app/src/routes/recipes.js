import { Router } from 'express';
import { ensureAuth } from '../middleware/auth.js';
import { Recipes, generateUUID } from '../db.js';
import { mdToHtml, difficultyClass, truncate } from '../utils/format.js';
import { renderWithFlash, handleError } from '../utils/templates.js';

const router = Router();

const DIFFICULTY_LEVELS = ['Easy', 'Medium', 'Hard'];

const UUID_REGEX = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

const validateUUID = (id) => {
  return typeof id === 'string' && UUID_REGEX.test(id);
};

const transformRecipeList = (recipe) => ({
  ...recipe,
  difficultyClass: difficultyClass(recipe.difficulty),
  description: mdToHtml(truncate(recipe.description || '', 120)),
  servings: Number(recipe.servings) || 0,
  prep_time: String(recipe.prep_time || ''),
  cook_time: String(recipe.cook_time || '')
});

const transformRecipeDetail = (recipe) => ({
  ...recipe,
  description_html: mdToHtml(recipe.description || ''),
  difficultyClass: difficultyClass(recipe.difficulty),
  servings: Number(recipe.servings) || 0,
  prep_time: String(recipe.prep_time || ''),
  cook_time: String(recipe.cook_time || '')
});

const parseListFromText = (text) => text
  .split('\n')
  .map(s => s.trim())
  .filter(Boolean);

const validateRecipeData = (data) => {
  const { title, region, difficulty, prep_time, cook_time, servings, description, ingredients, steps } = data;
  
  const requiredFields = { title, difficulty, prep_time, cook_time, servings, ingredients, steps };
  const missingFields = Object.entries(requiredFields)
    .filter(([key, value]) => !value || String(value).trim() === '')
    .map(([key]) => key);

  if (missingFields.length > 0) {
    return { valid: false, message: `Please fill in all required fields: ${missingFields.join(', ')}` };
  }

  const servingsNum = parseInt(servings, 10);
  if (!servingsNum || servingsNum < 1) {
    return { valid: false, message: 'Servings must be a positive number' };
  }

  if (!DIFFICULTY_LEVELS.includes(difficulty)) {
    return { valid: false, message: 'Invalid difficulty level' };
  }

  return { 
    valid: true, 
    cleanData: {
      title: String(title),
      region: String(region) || null,
      description: String(description) || '',
      difficulty,
      servings: servingsNum,
      prep_time: String(prep_time),
      cook_time: String(cook_time),
      ingredients: String(ingredients),
      steps: String(steps)
    }
  };
};

router.post('/add', ensureAuth, async (req, res) => {
  try {
    const validation = validateRecipeData(req.body || {});
    
    if (!validation.valid) {
      return renderWithFlash(req, res, 'add_recipe', 'add', {
        user_name: req.session.user.name,
        formData: req.body
      }, 'error', validation.message);
    }

    const recipeId = generateUUID();
    await Recipes.create(
      recipeId,
      validation.cleanData.title,
      validation.cleanData.region,
      validation.cleanData.description,
      validation.cleanData.difficulty,
      validation.cleanData.servings,
      validation.cleanData.prep_time,
      validation.cleanData.cook_time,
      validation.cleanData.ingredients,
      validation.cleanData.steps,
      req.session.user.id
    );

    req.flash('success', 'Recipe added successfully!');
    res.redirect('/recipes');
    
  } catch (error) {
    handleError(req, res, 'add_recipe', 'add', {
      user_name: req.session.user.name,
      formData: req.body || {}
    }, error, 'An error occurred while adding the recipe');
  }
});

router.get('/add', ensureAuth, (req, res) => {
  res.render('add_recipe', {
    active: 'add',
    user_name: req.session.user.name,
    formData: {}
  });
});

router.get('/', ensureAuth, async (req, res) => {
  try {
    const rows = await Recipes.listForUser(req.session.user.id);
    const recipes = rows.map(transformRecipeList);
    
    res.render('recipes', {
      active: 'recipes',
      recipes
    });
    
  } catch (error) {
    handleError(req, res, 'recipes', 'list', { recipes: [] }, error, 'Unable to load recipes');
  }
});

router.get('/:id', ensureAuth, async (req, res) => {
  try {
    const id = req.params.id;
    
    if (!validateUUID(id)) {
      req.flash('error', 'Invalid recipe ID');
      return res.redirect('/recipes');
    }

    const recipe = await Recipes.findByIdForUser(id, req.session.user.id);
    if (!recipe) {
      req.flash('error', 'Recipe not found');
      return res.redirect('/recipes');
    }

    const transformedRecipe = transformRecipeDetail(recipe);
    const ingredientsList = parseListFromText(recipe.ingredients);
    const stepsList = parseListFromText(recipe.steps);

    res.render('recipe_detail', {
      active: 'recipes',
      recipe: transformedRecipe,
      ingredientsList,
      stepsList
    });
    
  } catch (error) {
    console.error('Recipe detail error:', error);
    req.flash('error', 'Unable to load recipe');
    res.redirect('/recipes');
  }
});

export default router;