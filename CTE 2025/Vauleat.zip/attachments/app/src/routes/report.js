import { Router } from 'express';
import crypto from 'crypto';
import { visit } from '../bot.js';

const router = Router();

const POW_SECRET = process.env.POW_SECRET || crypto.randomBytes(32);
const POW_DIFFICULTY = Number(process.env.POW_DIFFICULTY || 20);
const POW_TTL_MS = Number(process.env.POW_TTL_MS || 2 * 60 * 1000);
const POW_REQUIRED = (process.env.POW_REQUIRED ?? 'true').toLowerCase() !== 'false';
const POW_BIND_TO_IP = (process.env.POW_BIND_TO_IP ?? 'true').toLowerCase() !== 'false';

const usedPow = new Map();

console.log(`Pow difficulty: ${POW_DIFFICULTY}`);
console.log(`Pow TTL: ${POW_TTL_MS}ms`);
console.log(`Pow required: ${POW_REQUIRED}`);
console.log(`Pow bind to ip: ${POW_BIND_TO_IP}`);


function pruneUsedPow(now = Date.now()) {
  for (const [k, exp] of usedPow) {
    if (exp < now) usedPow.delete(k);
  }
}

function b64url(buf) {
  return Buffer.from(buf).toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, '');
}

function hmacSign({ token, expires, difficulty, clientId }) {
  const h = crypto.createHmac('sha256', POW_SECRET);
  h.update(String(token));
  h.update('|');
  h.update(String(expires));
  h.update('|');
  h.update(String(difficulty));
  h.update('|');
  h.update(POW_BIND_TO_IP ? String(clientId) : '');
  return b64url(h.digest());
}

function constantTimeEqual(a, b) {
  const A = Buffer.from(a);
  const B = Buffer.from(b);
  if (A.length !== B.length) return false;
  return crypto.timingSafeEqual(A, B);
}

function sha256Buf(str) {
  return crypto.createHash('sha256').update(str).digest();
}

function countLeadingZeroBits(buf) {
  let bits = 0;
  for (const byte of buf) {
    if (byte === 0) {
      bits += 8;
      continue;
    }
    
    for (let i = 7; i >= 0; i--) {
      if ((byte & (1 << i)) === 0) bits++;
      else return bits;
    }
  }
  return bits;
}

function getClientId(req) {
  const fwd = req.headers['x-forwarded-for'];
  if (typeof fwd === 'string' && fwd.length > 0) {
    const first = fwd.split(',')[0].trim();
    if (first) return first;
  }
  return req.ip || req.connection?.remoteAddress || '';
}

router.get('/report/pow', (req, res) => {
  const clientId = getClientId(req);
  const token = b64url(crypto.randomBytes(16));
  const difficulty = POW_DIFFICULTY;
  const expires = Date.now() + POW_TTL_MS;
  const sig = hmacSign({ token, expires, difficulty, clientId });

  return res.json({
    alg: 'sha256',
    token,
    difficulty,
    expires,
    sig,
  });
});

router.post('/report', async (req, res) => {
  res.type('text/plain');

  const { url, pow } = req.body || {};

  if (typeof url !== 'string') {
    return res.status(400).send('Invalid URL');
  }

  try {
    const parsedUrl = new URL(url);
    if (parsedUrl.protocol !== 'http:' && parsedUrl.protocol !== 'https:') {
      return res.status(400).send('Invalid URL');
    }
  } catch {
    return res.status(400).send('Invalid URL');
  }

  if (POW_REQUIRED) {
    if (
      !pow ||
      typeof pow !== 'object' ||
      typeof pow.token !== 'string' ||
      typeof pow.nonce !== 'string' ||
      typeof pow.sig !== 'string' ||
      typeof pow.expires !== 'number' ||
      typeof pow.difficulty !== 'number'
    ) {
      return res.status(400).send('Missing or invalid PoW');
    }

    const now = Date.now();
    if (pow.expires < now) {
      return res.status(400).send('PoW expired');
    }

    if (pow.difficulty !== POW_DIFFICULTY) {
      return res.status(400).send('Invalid PoW');
    }

    const clientId = getClientId(req);
    const expectedSig = hmacSign({
      token: pow.token,
      expires: pow.expires,
      difficulty: pow.difficulty,
      clientId,
    });

    if (!constantTimeEqual(expectedSig, pow.sig)) {
      return res.status(400).send('Invalid PoW');
    }

    pruneUsedPow(now);

    const usedKey = `${pow.token}:${pow.nonce}`;

    if (usedPow.has(usedKey) && usedPow.get(usedKey) >= now) {
      return res.status(429).send('PoW already used');
    }

    const hash = sha256Buf(`${pow.token}.${pow.nonce}`);
    const lz = countLeadingZeroBits(hash);

    if (lz < pow.difficulty) {
      return res.status(400).send('Invalid PoW');
    }

    usedPow.set(usedKey, pow.expires);
  }

  try {
    const result = await visit(url);

    return res.send(result);
  } catch (err) {
    return res.status(400).send('Invalid URL');
  }
});

export default router;
