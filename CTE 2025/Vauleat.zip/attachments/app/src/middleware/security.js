import crypto from 'crypto';

export function nonceMiddleware(req, res, next) {
  res.locals.cspNonce = crypto.randomBytes(16).toString('base64');
  next();
}

export function maliciousRequestsMiddleware(req, res, next){
  // prevent csrf
  if(req.headers && req.headers.referer) {
    return res.type('text/plain').send('CSRF detected');
  }

  next();
}

export function addHeadersMiddleware(req, res, next) {
  const nonce = res.locals.cspNonce;
  const csp = [
    "default-src 'none'",
    "img-src data:",
    `script-src 'self' 'nonce-${nonce}'`,
    `style-src 'self' https://cdnjs.cloudflare.com https://fonts.googleapis.com 'nonce-${nonce}'`,
    "font-src https://cdnjs.cloudflare.com https://fonts.gstatic.com",
    "object-src 'none'",
    "base-uri 'none'",
    "form-action 'self'",
  ].join('; ');

  res.setHeader('Content-Security-Policy', csp);
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader("Document-Policy", "force-load-at-top");
  res.setHeader("Referrer-Policy", "no-referrer")
  res.setHeader('Cache-Control', 'no-store');
  res.setHeader('Pragma', 'no-cache');
  res.setHeader('Expires', '0');

  next();
}
