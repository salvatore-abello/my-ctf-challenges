
import mysql from 'mysql2/promise';
import crypto from 'crypto';

const dbConfig = {
  host: process.env.DB_HOST || 'mysql',
  user: process.env.DB_USER || 'vauleat',
  password: process.env.DB_PASSWORD || 'supersecret',
  database: process.env.DB_NAME || 'vauleat_db',
  charset: 'utf8mb4',
  connectionLimit: 10,
  acquireTimeout: 60000,
  timeout: 60000,
};

export const pool = mysql.createPool(dbConfig);

export const generateUUID = () => crypto.randomUUID();

export const initializeDatabase = async () => {
  const connection = await pool.getConnection();
  
  try {
    await connection.execute(`
      CREATE TABLE IF NOT EXISTS users (
        id VARCHAR(36) PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        email VARCHAR(255) NOT NULL UNIQUE,
        password_hash VARCHAR(255) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        CONSTRAINT chk_name_length CHECK (CHAR_LENGTH(name) > 0),
        CONSTRAINT chk_password_length CHECK (CHAR_LENGTH(password_hash) > 0)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    `);

    await connection.execute(`
      CREATE TABLE IF NOT EXISTS recipes (
        id VARCHAR(36) PRIMARY KEY,
        title VARCHAR(255) NOT NULL,
        region VARCHAR(255),
        description TEXT,
        difficulty ENUM('Easy', 'Medium', 'Hard') NOT NULL DEFAULT 'Easy',
        servings INTEGER NOT NULL,
        prep_time VARCHAR(255) NOT NULL,
        cook_time VARCHAR(255) NOT NULL,
        ingredients TEXT NOT NULL,
        steps TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        user_id VARCHAR(36) NOT NULL,
        CONSTRAINT chk_title_length CHECK (CHAR_LENGTH(title) > 0),
        CONSTRAINT chk_servings_positive CHECK (servings > 0),
        CONSTRAINT chk_prep_time_length CHECK (CHAR_LENGTH(prep_time) > 0),
        CONSTRAINT chk_cook_time_length CHECK (CHAR_LENGTH(cook_time) > 0),
        CONSTRAINT chk_ingredients_length CHECK (CHAR_LENGTH(ingredients) > 0),
        CONSTRAINT chk_steps_length CHECK (CHAR_LENGTH(steps) > 0),
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
        INDEX idx_recipes_user (user_id, created_at DESC),
        INDEX idx_recipes_difficulty (difficulty)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    `);

    const [indexes] = await connection.query(`
      SHOW INDEX FROM users WHERE Key_name = 'idx_users_email'
    `);

    if (indexes.length === 0) {
      await connection.execute(`
        CREATE INDEX idx_users_email ON users(email)
      `);
    }

    console.log('Database tables initialized successfully');
  } catch (error) {
    console.error('Error initializing database:', error);
    throw error;
  } finally {
    connection.release();
  }
};

export const Users = {
  async findByEmail(email) {
    const [rows] = await pool.execute(
      'SELECT id, name, email, password_hash FROM users WHERE email = ?',
      [email]
    );
    return rows[0] || null;
  },

  async findById(id) {
    const [rows] = await pool.execute(
      'SELECT id, name, email FROM users WHERE id = ?',
      [id]
    );
    return rows[0] || null;
  },

  async create(id, name, email, passwordHash) {
    await pool.execute(
      'INSERT INTO users (id, name, email, password_hash) VALUES (?, ?, ?, ?)',
      [id, name, email, passwordHash]
    );
  }
};

export const Recipes = {
  async latestForUser(userId) {
    const [rows] = await pool.execute(`
      SELECT id, title, region, description, difficulty, servings, prep_time, cook_time, created_at 
      FROM recipes WHERE user_id = ? ORDER BY created_at DESC LIMIT 6
    `, [userId]);
    return rows;
  },

  async listForUser(userId) {
    const [rows] = await pool.execute(`
      SELECT id, title, region, description, difficulty, servings, prep_time, cook_time, ingredients, steps, created_at 
      FROM recipes WHERE user_id = ? ORDER BY created_at DESC
    `, [userId]);
    return rows;
  },

  async create(id, title, region, description, difficulty, servings, prepTime, cookTime, ingredients, steps, userId) {
    await pool.execute(`
      INSERT INTO recipes (id, title, region, description, difficulty, servings, prep_time, cook_time, ingredients, steps, user_id)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `, [id, title, region, description, difficulty, servings, prepTime, cookTime, ingredients, steps, userId]);
  },

  async findByIdForUser(id, userId) {
    const [rows] = await pool.execute(`
      SELECT id, title, region, description, difficulty, servings, prep_time, cook_time, ingredients, steps, created_at
      FROM recipes WHERE id = ? AND user_id = ?
    `, [id, userId]);
    return rows[0] || null;
  },

  async countForUser(userId) {
    const [rows] = await pool.execute(
      'SELECT COUNT(*) as count FROM recipes WHERE user_id = ?',
      [userId]
    );
    return rows[0];
  }
};