import puppeteer from "puppeteer";
import crypto from "crypto";

const SITE = (process.env.SITE || "https://localhost:3000").replace(/\/+$/, "");

const FLAG = process.env.FLAG || "CTE{fake_flag_for_testing}";
const FLAG_REGEX = /^CTE{[a-zA-Z0-9_]+}$/;

const sleep = async (ms) => new Promise((resolve) => setTimeout(resolve, ms));

const visit = (url) => {
    return new Promise(async (resolve, reject) => {
        if (!FLAG_REGEX.test(FLAG)) {
            return reject(new Error("Error: Flag does not match flag regex, contact an admin if this is on remote"));
        }

        let browser, context, page;
        try {
            browser = await puppeteer.launch({
                headless: true,
                args: [
                    '--no-sandbox',
                    '--disable-setuid-sandbox',
                    '--js-flags=--jitless',
                    "--disable-features=HttpsFirstBalancedModeAutoEnable",
                    '--ignore-certificate-errors',
                   
                    // uncomment this if you're running the challenge locally and you're having problems with the bot
                    // '--disable-features=TrackingProtection3pcd,LocalNetworkAccessChecks'
                ],
                dumpio: true,
                pipe: true,
                executablePath: process.env.PUPPETEER_EXECUTABLE_PATH
            });

            context = await browser.createBrowserContext();

            page = await context.newPage();
            await page.goto(`${SITE}/register`, { waitUntil: "domcontentloaded", timeout: 5000 });
            
            const adminName = `admin-${crypto.randomUUID()}`;
            const adminEmail = `admin-${crypto.randomUUID()}@example.com`;
            const adminPassword = crypto.randomBytes(32).toString("hex");
            
            console.log(`admin name: ${adminName}`);
            console.log(`admin email: ${adminEmail}`);
            console.log(`admin password: ${adminPassword}`);

            await page.type("input[name=name]", adminName);
            await page.type("input[name=email]", adminEmail);
            await page.type("input[name=password]", adminPassword);
            await page.type("input[name=confirmPassword]", adminPassword);
            await page.click("button[type=submit]");
            await sleep(1500);

            await page.goto(`${SITE}/login`, { waitUntil: "domcontentloaded", timeout: 5000 });
            await page.type("input[name=email]", adminEmail);
            await page.type("input[name=password]", adminPassword);
            await page.click("button[type=submit]");
            await sleep(1500);

            await page.goto(`${SITE}/recipes/add`, { waitUntil: "domcontentloaded", timeout: 5000 });
            await page.type("input[name=title]", "The Flag");
            await page.type("input[name=region]", "Italy");
            await page.type("textarea[name=description]", FLAG);
            await page.select("select[name=difficulty]", "Medium");
            await page.type("input[name=servings]", "1");
            await page.type("input[name=prep_time]", "1");
            await page.type("input[name=cook_time]", "15");
            await page.type("textarea[name=ingredients]", "something\nsomething");
            await page.type("textarea[name=steps]", "Get the flag");

            await page.click("#submit-button");
            await sleep(1500);

            await page.close();
        } catch (err) {
            console.error(err);
            if (browser) await browser.close();
            return reject(new Error("Error: Setup failed, if this happens consistently on remote contact an admin"));
        }

        resolve(`The admin will visit ${SITE} first and then ${url}`);

        try {
            page = await context.newPage();
            await page.goto(url, { waitUntil: "domcontentloaded", timeout: 5000 });
            await sleep(2000);
        } catch (err) {
            console.error(err);
        }

        if (browser) await browser.close();
    });
};

export { visit };
