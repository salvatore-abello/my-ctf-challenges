export const renderWithFlash = (req, res, template, active, data, errorType = 'error', message = null) => {
  const existingFlash = {
    success: req.flash('success'),
    error: req.flash('error'),
  };
  
  if (message) {
    existingFlash[errorType].push(message);
  }
  
  res.render(template, {
    active,
    flash: existingFlash,
    ...data
  });
};

export const handleError = (req, res, template, active, data, error, defaultMessage) => {
  console.error(`${active} error:`, error);
  
  let message = defaultMessage;
  if (error.code === 'SQLITE_CONSTRAINT_UNIQUE') {
    message = 'An account with this email already exists';
  }
  
  renderWithFlash(req, res, template, active, data, 'error', message);
};