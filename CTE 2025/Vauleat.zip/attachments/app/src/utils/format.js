
import MarkdownIt from 'markdown-it';
import * as parse5 from 'parse5';

const md = new MarkdownIt({
  html: true,
  linkify: true,
  typographer: true
});

export function truncate(s = '', n = 120) {
  s = String(s);
  return s.length > n ? s.slice(0, n - 1) + '...' : s;
}

export function difficultyClass(d = '') {
  const difficulty = String(d || '').toLowerCase();
  const validClasses = ['easy', 'medium', 'hard'];
  return validClasses.includes(difficulty) ? difficulty : 'easy';
}

export function mdToHtml(text) {
    // render markdown and prevent broken tags
    const rendered = md.render(text);
    const frag = parse5.parseFragment(`<div>${rendered}</div>`);
    return frag.childNodes.map(node => parse5.serialize(node)).join('');
}
